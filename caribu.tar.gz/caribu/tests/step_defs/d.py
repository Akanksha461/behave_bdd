from selenium import webdriver
import time
path ="/home/ak/PycharmProjects/chromedriver"

driver = webdriver.Chrome(executable_path=path)
driver.get('https://caribu-dev-firebase.web.app/')
time.sleep(5)
#sign_in = driver.find_element_by_class_name('sc-fzXfNO cjNSCe')
driver.find_element_by_link_text('Sign In').click()
print('caribu')
