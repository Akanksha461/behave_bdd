import os

TEST_ENV = os.getenv('TEST_ENV')
URL = os.getenv('URL')
print(URL)
